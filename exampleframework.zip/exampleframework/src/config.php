<?php

if(!defined("DB_TYPE"))
    define("DB_TYPE", "mysql");
if(!defined("DB_HOST"))
    define("DB_HOST", "localhost");
 if(!defined("DB_NAME"))
    define("DB_NAME", "db_ecommerce");
if(!defined("DB_USER"))
    define("DB_USER", "root");
 if(!defined("DB_PWD"))
    define("DB_PWD", "wordpass");
if(!defined("DEFAULT_CONTROLLER"))
    define("DEFAULT_CONTROLLER", "welcome");

?>