<?php

echo($msg);
?>
<p>
This is the error page.
</p>
