
    <h3><?=$name?></h3>
     <?php
        print_r($students);
     ?>
