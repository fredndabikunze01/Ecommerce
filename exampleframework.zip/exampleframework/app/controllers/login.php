<?php
class Login extends Controller{
    private $data = [];
    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $this->view->render("login_view", $this->data);
    }
}