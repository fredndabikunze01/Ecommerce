
<?php
//echo $_GET['req'];
require_once 'src/autoload.php';
$autoload = new Autoload();
?>